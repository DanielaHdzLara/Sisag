-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-03-2019 a las 04:24:21
-- Versión del servidor: 10.1.34-MariaDB
-- Versión de PHP: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sisag`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `maiz`
--

CREATE TABLE `maiz` (
  `crecimiento` int(11) DEFAULT NULL,
  `kc` float DEFAULT NULL,
  `recomendacion` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `maiz`
--

INSERT INTO `maiz` (`crecimiento`, `kc`, `recomendacion`) VALUES
(10, 0.3, NULL),
(20, 0.5, NULL),
(30, 0.7, NULL),
(40, 0.87, NULL),
(50, 0.81, NULL),
(60, 0.82, NULL),
(70, 0.75, NULL),
(80, 0.65, NULL),
(90, 0.45, NULL),
(100, 0.35, NULL),
(NULL, NULL, 'Perfil de suelo no compactado: Su cultivo tiene pocos días de haberse sembrado, es necesario realizar una verificación del suelo en el cual se cultivo la semilla para estar seguros que no se encuentra');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mis_cultivos`
--

CREATE TABLE `mis_cultivos` (
  `id` mediumint(9) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `fecha_siembra` date DEFAULT NULL,
  `terreno` float DEFAULT NULL,
  `dias_transcurridos` double DEFAULT NULL,
  `dias_desarrollo` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `mis_cultivos`
--

INSERT INTO `mis_cultivos` (`id`, `nombre`, `fecha_siembra`, `terreno`, `dias_transcurridos`, `dias_desarrollo`) VALUES
(1, 'Maíz', '2019-03-06', 20, 15, 112);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `mis_cultivos`
--
ALTER TABLE `mis_cultivos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `mis_cultivos`
--
ALTER TABLE `mis_cultivos`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
